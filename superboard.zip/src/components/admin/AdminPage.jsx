import { useState, useEffect } from 'react';
import { collection, getDocs, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase/config.js';

const ADMIN_EMAILS = ['shg090404@gmail.com', 'face69troll69@gmail.com'];

export default function AdminPage({ user, onBack }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [boards, setBoards] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalBoards: 0,
    publicBoards: 0,
    privateBoards: 0,
    totalUsers: 0,
  });

  const isAdmin = user && ADMIN_EMAILS.includes(user.email);

  useEffect(() => {
    if (isAdmin) {
      loadData();
    }
  }, [isAdmin]);

  async function loadData() {
    setLoading(true);
    try {
      const boardsSnap = await getDocs(collection(db, 'boards'));
      const boardsList = boardsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBoards(boardsList);

      const usersMap = new Map();
      boardsList.forEach(board => {
        if (board.ownerId && !usersMap.has(board.ownerId)) {
          usersMap.set(board.ownerId, {
            uid: board.ownerId,
            email: board.ownerEmail,
            name: board.ownerName || board.ownerEmail,
            boardCount: 0,
          });
        }
        if (board.ownerId) {
          const u = usersMap.get(board.ownerId);
          u.boardCount++;
        }
      });
      setUsers(Array.from(usersMap.values()));

      setStats({
        totalBoards: boardsList.length,
        publicBoards: boardsList.filter(b => b.visibility === 'public').length,
        privateBoards: boardsList.filter(b => b.visibility === 'private').length,
        totalUsers: usersMap.size,
      });
    } catch (err) {
      console.error('Failed to load admin data:', err);
      alert('Failed to load data. Check console for details.');
    }
    setLoading(false);
  }

  async function deleteBoard(boardId) {
    if (!confirm('Delete this board permanently? This cannot be undone.')) return;
    try {
      await deleteDoc(doc(db, 'boards', boardId));
      setBoards(prev => prev.filter(b => b.id !== boardId));
      setStats(prev => ({ ...prev, totalBoards: prev.totalBoards - 1 }));
      alert('Board deleted successfully');
    } catch (err) {
      console.error('Delete failed:', err);
      alert('Failed to delete board');
    }
  }

  async function toggleVisibility(boardId, currentVis) {
    const newVis = currentVis === 'public' ? 'private' : 'public';
    try {
      await updateDoc(doc(db, 'boards', boardId), { visibility: newVis });
      setBoards(prev => prev.map(b => 
        b.id === boardId ? { ...b, visibility: newVis } : b
      ));
      alert(`Board is now ${newVis}`);
    } catch (err) {
      alert('Failed to update visibility');
    }
  }

  function formatDate(ts) {
    if (!ts) return 'N/A';
    const d = ts?.toDate ? ts.toDate() : new Date(ts);
    return d.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (!isAdmin) {
    return (
      <div className="error-page">
        <div className="glass-card error-card">
          <div className="error-icon" style={{ background: 'rgba(239,68,68,0.1)' }}>🔒</div>
          <div className="error-title">Access Denied</div>
          <div className="error-text">You do not have admin privileges.</div>
          <button className="btn btn-primary" onClick={onBack}>Go Back</button>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <header className="admin-header glass-strong">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="btn-icon" onClick={onBack} title="Dashboard">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>
          <div>
            <h1 className="admin-title">Admin Panel</h1>
            <p className="admin-subtitle">Superboard Management</p>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="badge badge-amber">Admin</span>
          <span style={{ fontSize: 13, color: 'var(--tx-3)' }}>{user.email}</span>
          <button
            className="btn btn-ghost"
            onClick={loadData}
            style={{ padding: '6px 12px', fontSize: 13 }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="23 4 23 10 17 10"/>
              <path d="M20.49 15a9 9 0 11-2.13-9.36L23 10"/>
            </svg>
            Refresh
          </button>
        </div>
      </header>

      <div className="admin-tabs">
        <button
          className={'admin-tab' + (activeTab === 'overview' ? ' active' : '')}
          onClick={() => setActiveTab('overview')}
        >
          Overview
        </button>
        <button
          className={'admin-tab' + (activeTab === 'boards' ? ' active' : '')}
          onClick={() => setActiveTab('boards')}
        >
          All Boards ({stats.totalBoards})
        </button>
        <button
          className={'admin-tab' + (activeTab === 'users' ? ' active' : '')}
          onClick={() => setActiveTab('users')}
        >
          Users ({stats.totalUsers})
        </button>
      </div>

      <div className="admin-content">
        {loading ? (
          <div className="admin-loading">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--a)" strokeWidth="2"
              style={{ animation: 'spin 1s linear infinite' }}>
              <path d="M21 12a9 9 0 11-6.219-8.56"/>
            </svg>
            <span>Loading data...</span>
          </div>
        ) : (
          <>
            {activeTab === 'overview' && (
              <div className="admin-overview">
                <div className="stats-grid">
                  <div className="stat-card">
                    <div className="stat-icon" style={{ background: 'rgba(99, 102, 241, 0.1)' }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--a)" strokeWidth="2">
                        <rect x="3" y="3" width="18" height="18" rx="2"/>
                        <path d="M3 9h18"/>
                      </svg>
                    </div>
                    <div className="stat-value">{stats.totalBoards}</div>
                    <div className="stat-label">Total Boards</div>
                  </div>

                  <div className="stat-card">
                    <div className="stat-icon" style={{ background: 'rgba(34, 197, 94, 0.1)' }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--green)" strokeWidth="2">
                        <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
                      </svg>
                    </div>
                    <div className="stat-value">{stats.publicBoards}</div>
                    <div className="stat-label">Public Boards</div>
                  </div>

                  <div className="stat-card">
                    <div className="stat-icon" style={{ background: 'rgba(245, 158, 11, 0.1)' }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--amber)" strokeWidth="2">
                        <rect x="3" y="11" width="18" height="11" rx="2"/>
                        <path d="M7 11V7a5 5 0 0110 0v4"/>
                      </svg>
                    </div>
                    <div className="stat-value">{stats.privateBoards}</div>
                    <div className="stat-label">Private Boards</div>
                  </div>

                  <div className="stat-card">
                    <div className="stat-icon" style={{ background: 'rgba(139, 92, 246, 0.1)' }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" strokeWidth="2">
                        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 00-3-3.87"/>
                        <path d="M16 3.13a4 4 0 010 7.75"/>
                      </svg>
                    </div>
                    <div className="stat-value">{stats.totalUsers}</div>
                    <div className="stat-label">Active Users</div>
                  </div>
                </div>

                <div className="info-section">
                  <h3 className="section-title">Quick Actions</h3>
                  <div className="quick-actions">
                    <button className="action-btn" onClick={() => setActiveTab('boards')}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="3" width="18" height="18" rx="2"/>
                      </svg>
                      Manage All Boards
                    </button>
                    <button className="action-btn" onClick={() => setActiveTab('users')}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                      </svg>
                      View All Users
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'boards' && (
              <div className="admin-boards">
                <div className="admin-table-wrapper">
                  <table className="admin-table">
                    <thead>
                      <tr>
                        <th>Board Name</th>
                        <th>Owner</th>
                        <th>Visibility</th>
                        <th>Created</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {boards.map(board => (
                        <tr key={board.id}>
                          <td className="board-name-cell">
                            <div className="board-name">{board.name}</div>
                            <div className="board-id">ID: {board.id.slice(0, 8)}...</div>
                          </td>
                          <td>
                            <div className="owner-cell">
                              <div className="owner-name">{board.ownerName || 'Unknown'}</div>
                              <div className="owner-email">{board.ownerEmail}</div>
                            </div>
                          </td>
                          <td>
                            <span className={'badge ' + (board.visibility === 'public' ? 'badge-green' : 'badge-amber')}>
                              {board.visibility}
                            </span>
                          </td>
                          <td className="date-cell">{formatDate(board.createdAt)}</td>
                          <td>
                            <div className="action-buttons">
                              <button
                                className="btn-icon"
                                onClick={() => toggleVisibility(board.id, board.visibility)}
                                title="Toggle visibility"
                              >
                                {board.visibility === 'public' ? (
                                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <rect x="3" y="11" width="18" height="11" rx="2"/>
                                    <path d="M7 11V7a5 5 0 0110 0v4"/>
                                  </svg>
                                ) : (
                                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
                                  </svg>
                                )}
                              </button>
                              <button
                                className="btn-icon btn-danger"
                                onClick={() => deleteBoard(board.id)}
                                title="Delete board"
                              >
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <polyline points="3 6 5 6 21 6"/>
                                  <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                                </svg>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="admin-users">
                <div className="admin-table-wrapper">
                  <table className="admin-table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Boards Owned</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map(u => (
                        <tr key={u.uid}>
                          <td className="user-name-cell">{u.name}</td>
                          <td className="user-email-cell">{u.email}</td>
                          <td>{u.boardCount}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}